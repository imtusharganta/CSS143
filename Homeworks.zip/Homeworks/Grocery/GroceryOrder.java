
/**
 * This class just extends ArrayList
 */

import java.util.*;

public class GroceryOrder<T> extends ArrayList<T> {
}
