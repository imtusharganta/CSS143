public class GroceryException extends Exception {
  public GroceryException() {
    super();
  }

  public GroceryException(String message) {
    super(message);
  }
}
