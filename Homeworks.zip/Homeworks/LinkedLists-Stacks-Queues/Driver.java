public class Driver {

  /**
   * DO NOT RUN. NO NEED TO RUN. ALL CLASSES HAVE THEIR OWN MAIN METHOD
   */
  // public static void main(String[] args) {
  // List empty = new List();
  // List one = new List();
  // List multiple = new List();
  // List tester = new List();
  // try {
  // one.insert(5, 0);
  // multiple.insert(10, 0);
  // multiple.insert(20, 0);
  // multiple.insert(30, 0);
  // multiple.insert('T', 0);
  // multiple.insert('T', 2);
  // multiple.insert('T', 4);
  // System.out.println("Empty:" + empty);
  // System.out.println("One:" + one);
  // System.out.println("Multiple:" + multiple);
  // one.remove(0);
  // multiple.remove(1);
  // System.out.println("One (upon remove 1):" + one);
  // System.out.println("Multiple (upon remove):" + multiple);
  // one.insert(600, 1);
  // multiple.insert(400, 2);
  // System.out.println("One (on insert at 1):" + one);
  // System.out.println("Multiple(on insert at 2):" + multiple);
  // System.out.println("Tester: " + tester);
  // // test error
  // empty.remove(3);
  // } catch (LinkedListException e) {
  // System.out.println(e.getMessage());
  // }
  // }
}
