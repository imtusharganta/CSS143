/**
 * LinkedListException Class
 */
public class LinkedListException extends Exception {

  public LinkedListException() {
    super();
  }

  public LinkedListException(String message) {
    super(message);
  }

}
