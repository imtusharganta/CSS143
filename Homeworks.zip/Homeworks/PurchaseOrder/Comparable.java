public interface Comparable {

}
